# half_n_half

![half_n_half](https://2.bp.blogspot.com/-akouSRzGKQw/WutIH4qV0nI/AAAAAAACRqA/D1Gx3i1UWlccMCd0VS8td0ckWjCixrSuQCLcBGAs/s1600/b.jpg)

A small split ortho board with two thumb keys

Keyboard Maintainer: [Boy_314](https://github.com/boy-314)  
Hardware Availability: http://www.40percent.club/2018/07/half-n-half.html

Make example for this keyboard (after setting up your build environment):

    make 40percentclub/half_n_half:default

See the [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) and the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information. Brand new to QMK? Start with our [Complete Newbs Guide](https://docs.qmk.fm/#/newbs).
