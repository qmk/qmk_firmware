# 40% Keyboards

Website: [40percent.club](http://www.40percent.club/)  
The original TMK firmware: [repo](https://github.com/di0ib/tmk_keyboard/tree/master/keyboard/)
