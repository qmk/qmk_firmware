WS2812B LED added and connected to pin D3 as described here: https://www.40percent.club/2018/04/gnap-underglow.html
