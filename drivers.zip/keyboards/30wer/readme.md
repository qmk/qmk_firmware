30wer by 8o7wer
===

![30wer](https://i.imgur.com/ZYbRvY7.png)

Keyboard Maintainer: [Filip Sund](https://github.com/FSund)  
Hardware Supported: Pro Micro  
Hardware Availability: Group buy

More info in the [group by thread at Keebtalk](https://www.keebtalk.com/t/gb-30wer-by-8o7wer/3618/).

Make example for this keyboard (after setting up your build environment):

    make 30wer:default

See the [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) and the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information. Brand new to QMK? Start with our [Complete Newbs Guide](https://docs.qmk.fm/#/newbs).