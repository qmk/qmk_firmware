#pragma once

#ifndef CONVERT_TO_PROTON_C
#    define LED_NUM_LOCK_PIN B0 // RXLED
#    define LED_CAPS_LOCK_PIN D5 // TXLED
#    define LED_PIN_ON_STATE 0
#endif
