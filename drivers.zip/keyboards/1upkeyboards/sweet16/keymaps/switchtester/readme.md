# Sweet16 as a switch tester

This keymap uses the Sweet16 as a switch tester. The functionality outputs the switch name of whatever key the user pressed.

the `switches` two-dimensional (4x4) array contains the switches attached to the macropad. The switches supported are defined as macros in the `switches.h` header file.
