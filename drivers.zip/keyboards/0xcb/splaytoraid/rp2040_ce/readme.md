# rp2040_ce

This folder is set as default in the parent rules.mk - it will build firmware compatible with the RP2040 Community Edition. See [here](https://docs.qmk.fm/#/platformdev_rp2040?id=rp2040_ce) for a list.
