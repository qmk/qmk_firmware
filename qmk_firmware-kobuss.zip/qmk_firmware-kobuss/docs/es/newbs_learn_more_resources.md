# Recursos de aprendizaje

Estos recursos procuran dar miembros nuevos en la communidad QMK un mayor entendimiento de la información proporcionada en la documentación para novatos.

Recursos de Git:

* [Excelente tutorial general](https://www.codecademy.com/learn/learn-git)
* [Juego de Git para aprender usando ejemplos](https://learngitbranching.js.org/)
* [Recursos de Git para aprender más sobre GitHub](getting_started_github.md)
* [Recursos de Git dirigidos específicamente a QMK](contributing.md)


Recursos para línea de mandatos:

* [Excelente tutorial general sobre la línea de mandatos](https://www.codecademy.com/learn/learn-the-command-line)
