# 도움 받기

QMK에서 도움을 받는 방법은 다양합니다.

**주의, 아래 링크들은 영어로 이루어져 있으며 영어 사용이 가능해야 편리하게 이용할 수 있습니다.**

## 디스코드 실시간 채팅

[QMK 디스코드 서버](https://discord.gg/Uq7gcHh)에서 QMK 개발자들과 실시간으로 대화를 나눌수있습니다. 이 디스코드에는 펌웨어, 툴박스, 하드웨어, 그리고 컨피겨레이터(configurator)에 관한 특별화된 채널이 운영되고 있습니다.

## OLKB 서브레딧

공식 QMK 포럼은 [reddit.com](https://reddit.com) 에 [/r/olkb](https://reddit.com/r/olkb)입니다.

## Github 이슈

[issue on GitHub](https://github.com/qmk/qmk_firmware/issues)에서 문제를 보고 할 수 있습니다. 이 링크는 문제가 오랜 시간을 필요로하거나 디버깅를 요구 할때 매우 유용합니다.
