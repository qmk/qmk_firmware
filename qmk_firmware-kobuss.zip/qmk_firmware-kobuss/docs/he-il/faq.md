<div dir="rtl" markdown="1">
# שאלות נפוצות

* [כללי](faq_general.md)
* [בנייה או קומפילציה של QMK](faq_build.md)
* [דיבאגינג ופתרון בעיות של QMK](faq_debug.md)
* [מיפוי מקשים](faq_keymap.md)
</div>
