<div dir="rtl" markdown="1">
# חומרה

QMK רצה על מגוון של חומרות. אם המעבד שלך יכול להיות ממוקד (מטורגט) ע״י [LUFA](http://www.fourwalledcubicle.com/LUFA.php) או [ChibiOS](http://www.chibios.com) כנראה שתוכל לגרום ל QMK לרוץ על המעבד. קטע זה מדבר על הרצת QMK, ותקשורת עם, סוגים שונים של חומרות.

* [מדריך למקלדת](hardware_keyboard_guidelines.md)
* [מעבדי AVR](hardware_avr.md)
* מעבדי ARM (TBD)
* [מנהלי התקנים](hardware_drivers.md)
</div>
