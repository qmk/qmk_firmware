# Iris LM

The Iris LM comes in two variants:

- [Iris LM-G](g1/readme.md) - Supports Gateron KS-33 low-profile switches
- [Iris LM-K](k1/readme.md) - Supports Kailh Choc V1 & V2 low-profile switches
