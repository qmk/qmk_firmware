# UniGo66

![UniGo66](https://i.imgur.com/ZKlcncg.png)

The UniGo66 is an ergonomic wireless keyboard designed by Sirius and manufactured by ALF Studios. 

Join ALF Studios on [Discord](https://discord.gg/GJ8bdM)

Make example:

	make sirius/unigo66:default

See the [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) and the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information. Brand new to QMK? Start with our [Complete Newbs Guide](https://docs.qmk.fm/#/newbs).

To get the U2U into DFU flashing mode, insert the U2U into the computer and press the button in the red circle shown below

![U2U](https://i.imgur.com/WKwgDjZ.png)