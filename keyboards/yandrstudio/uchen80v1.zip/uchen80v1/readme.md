uchen80v1
===

A 28 keys keyboard with rgb (keys).
This keyboard use 8mhz HSE and STM32F401 as MCU.

Keyboard Maintainer: https://github.com/jiaxin96
Hardware Supported: uchen80v1
Hardware Availability: https://github.com/Oh-My-Mechanical-Keyboard 

Make example for this keyboard (after setting up your build environment):

    make yandrstudio/uchen80v1/f401:default

See [build environment setup](https://docs.qmk.fm/#/getting_started_build_tools) then the [make instructions](https://docs.qmk.fm/#/getting_started_make_guide) for more information.
