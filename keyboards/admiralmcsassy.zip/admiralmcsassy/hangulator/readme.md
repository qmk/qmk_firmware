![Hangulator image here](link to image/image.jpg)

#define Hangulator Layout

It features more columnar offset, and pinky hangulation, hence the name.
