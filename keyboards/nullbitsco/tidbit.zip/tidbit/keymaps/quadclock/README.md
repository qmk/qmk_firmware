# Quad Clock Keymap

![quadclock_preview](https://user-images.githubusercontent.com/2514771/144528532-35243848-8512-4166-b27b-37905080ed42.jpg)

VIA compatible keymap that displays a live clock on your [quad alphanumeric display](https://www.adafruit.com/product/1911).

_Please note that this keymap requires a host app to be running in order to send the keymap time updates._

The required host app and instructions on how to run it can be found [here](/hosts/quadclock-host).
